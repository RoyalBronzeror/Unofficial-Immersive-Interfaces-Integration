bool posInRectX(vec3 position, vec2 screen, float offset, float size) {
    float rectMin = screen.x * 0.5 + offset;
    float rectMax = rectMin + size;
    return position.x >= rectMin && position.x <= rectMax;
}

bool posInRectY(vec3 position, vec2 screen, float offset, float size) {
    float rectMin = screen.y * 0.5 + offset;
    float rectMax = rectMin + size;
    return position.y >= rectMin && position.y <= rectMax;
}

float sliceX(float texCoordX, float cornerX, float atlasW, float spriteW, float a, float b) {
    float spriteUV = spriteW / atlasW;
    float baseX = texCoordX - cornerX * spriteUV;
    return baseX + (a + cornerX * (b - a)) * spriteUV;
}

float sliceY(float texCoordY, float cornerY, float atlasH, float spriteH, float a, float b) {
    float spriteUV = spriteH / atlasH;
    float baseY = texCoordY - cornerY * spriteUV;
    return baseY + (a + cornerY * (b - a)) * spriteUV;
}

vec2 sliceUV(vec2 texCoord, vec2 corner, vec2 atlasSize, vec2 spriteSize, vec2 a, vec2 b) {
    return vec2(
        sliceUV(texCoord.x, corner.x, atlasSize.x, spriteSize.x, a.x, b.x),
        sliceUV(texCoord.y, corner.y, atlasSize.y, spriteSize.y, a.y, b.y)
    );
}

Data integration(mat4 ProjMat, float GameTime, sampler2D Sampler0, vec3 Position, vec2 texCoord0) {
    
    vec3 pos = Position;
    vec2 texCoord = texCoord0;
    
    int vertID = gl_VertexID % 4;
    vec2 corner = corners[vertID];
    
    vec2 atlasSize = textureSize(Sampler0, 0);
    vec2 pixelSize = 1.0 / atlasSize; // One Pixel Size
    vec2 offsetBias = pixelSize * 0.5 * corner;
    vec4 color = round(texture(Sampler0, texCoord0 - offsetBias) * 255.0);
    
    vec2 screen = 2 / vec2(ProjMat[0][0], -ProjMat[1][1]);
    
    if (color.a == 1) { // Panels
    
        if (color.r == 255) { // Nomal Large
        
            pos.xy += ((corner - 0.5) * 2 * vec2(176, 166));
                    
        }
        if (color.r == 254) { // Enchanting Infuser Size
        
            pos.xy += ((corner - 0.5) * 2 * vec2(220, 185));
                    
        }
    
    }
    
    if (color.a == 2) { // Sprites
    
        if (color.r == 254) { // Enchanting Infuser
        
            if (color.g == 0) { // Infuser Button

                // Align all four vertices to the top of the row (relative to screen center)
                float rowTopY = Position.y - corner.y * 18.0 - screen.y * 0.5;
            
                float rowIndex = 0.0;
                if      (rowTopY >= -84.0 && rowTopY < -67.0) rowIndex = 0.0;
                else if (rowTopY >= -67.0 && rowTopY < -58.0) rowIndex = 1.0;
                else if (rowTopY >= -58.0 && rowTopY < -49.0) rowIndex = 2.0;
                else if (rowTopY >= -49.0 && rowTopY < -40.0) rowIndex = 3.0;
                else if (rowTopY >= -40.0 && rowTopY < -31.0) rowIndex = 4.0;
                else if (rowTopY >= -31.0 && rowTopY < -22.0) rowIndex = 5.0;
                else if (rowTopY >= -22.0)                       rowIndex = 6.0;
            
                // The UV height corresponding to the texture height in the atlas
                float spriteH = 126.0 / atlasSize.y;
            
                // Derive the top UV of the texture in the atlas
                float baseY = texCoord.y - corner.y * spriteH;
            
                // Map to the corresponding row (each row = 18px = spriteH / 7)
                texCoord.y = baseY + (rowIndex + corner.y) * spriteH / 7.0;
            
            }
            
            if (color.g == 1) { // Infuser Scroller
            
                // pos.xy += (corner - 0.5) * 2 * vec2(10, 10);
                
                if (posCheckX(Position, screen, 88, 12)) {
            
                    
            
                }
                            
            }
            
            if (color.g == 2) { // Infuser Add/Remove Button
                
                float rowTopY = Position.y - corner.y * 18.0 - screen.y * 0.5;
                if (rowTopY >= -31.0) texCoord.x = sliceX(texCoord.x, corner.x, atlasSize.x, 36.0, 0.5, 1.0);
                else texCoord.x = sliceX(texCoord.x, corner.x, atlasSize.x, 36.0, 0.0, 0.5);
                
                // ==========
                
                if (posCheckX(Position, screen, 62, 18) || posCheckX(Position, screen, -80, 18)) { // Without shift
                
                    texCoord.y = sliceY(texCoord.y, corner.y, atlasSize.y, 36.0, 0.5, 1.0);
                
                }
                
                else if (posCheckX(Position, screen, 59, 18)) {  // With shift Right Button
                
                    texCoord.y = sliceY(texCoord.y, corner.y, atlasSize.y, 36.0, 0.0, 0.5);
                    pos.x += 3.0;
                
                }
                
                else if (posCheckX(Position, screen, -77, 18)) {  // With shift Left Button
                
                    texCoord.y = sliceY(texCoord.y, corner.y, atlasSize.y, 36.0, 0.0, 0.5);
                    pos.x -= 3.0;
                
                }
                
                else return Data(vec3(-1000.0, -1000.0, 0.0), texCoord, vec4(0));
            
            }
        
        }
    
    }
    
    return Data(pos,texCoord,vec4(0));
}